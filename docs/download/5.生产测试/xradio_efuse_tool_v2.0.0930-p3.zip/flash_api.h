/*------------------------------------------------------------------------
* Xradio
* Reproduction and Communication of this document is strictly prohibited
* unless specifically authorized in writing by Xradio
*-------------------------------------------------------------------------
* Public header file between host application, flash_api.dll and firmware
*-----------------------------------------------------------------------*/

#ifndef _FLASH_API_H_
#define _FLASH_API_H_

#pragma once

#define LINKAGE	__declspec(dllexport)

#ifdef __cplusplus
extern "C"
{
#endif

/************************************************************
*                         flash use                         *
************************************************************/
	//Function:	Get last status message
	//Param:	no
	//Return:	pointer of message string
	LINKAGE char* FLASH_GetMsg();

	//Function:	Get the version of FLASH lib
	//Param:	no
	//Return:	pointer of version string
	LINKAGE char* FLASH_GetVersion(void);

	//Function:	Init UART and flash controler
	//Param:	comNum: UART COM port
	//Return:	0 - Success		1 - Failed
	LINKAGE int FLASH_InitFlash(int comNum);
	LINKAGE int FLASH_ExitFlash();

	//Function:	Read/Write/erase flash
	//Param:	buf: data buffer
	//			address: address to be read/write/erase
	//			len: read/write data length
	//			erase_size: block size to be erased
	//			1 - chip	2 - 64kb	3 - 32kb	4 - 4kb		else - invalid
	//Return:	0 - Success		1 - Failed
	LINKAGE int FLASH_ReadFlash(char* buf, int address, int len);
	LINKAGE int FLASH_WriteFlash(char* buf, int address, int len);
	LINKAGE int FLASH_EraseFlash(int address, int erase_size);

#ifdef __cplusplus
}
#endif

#endif // #ifndef _FLASH_API_H_