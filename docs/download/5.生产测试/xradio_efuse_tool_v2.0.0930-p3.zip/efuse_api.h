/*------------------------------------------------------------------------
* Xradio
* Reproduction and Communication of this document is strictly prohibited
* unless specifically authorized in writing by Xradio
*-------------------------------------------------------------------------
* Public header file between host application, efuse_api.dll and firmware
*-----------------------------------------------------------------------*/

#ifndef _EFUSE_API_H_
#define _EFUSE_API_H_

#pragma once

#define LINKAGE	__declspec(dllexport)

#ifdef __cplusplus
extern "C"
{
#endif

/************************************************************
*                         efuse use                         *
************************************************************/

	//Function:	Get last status message
	//Param:	no
	//Return:	pointer of message string
	LINKAGE char* EFUSE_GetMsg();
	LINKAGE int EFUSE_SetHashKey(char* buf, int len);

	//Function:	Get the version of EFUSE lib
	//Param:	no
	//Return:	pointer of version string
	LINKAGE char* EFUSE_GetVersion(void);

	//Function:	Test encode data
	//Param:	encodeKey:	TRUE - encode key buf only
	//						FALSE - read encode result of last time
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_EncodeTest(char* buf, int len, BOOL encodeKey);

	//Function:	Init UART and key buffer
	//Param:	comNum: UART COM port
	//			keyBuf: buffer of encode key
	//			len: length of encode key
	//			baud: COM baud rate, default 115200 if not set
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_InitEfuse(int comNum, char* keyBuf, int len, DWORD baud = 115200);
	LINKAGE int EFUSE_ExitEfuse();

	//Function:	Read/Write hosc
	//Param:	hosc: 0 - 26M   1 - 40M   2 - 24M   3 - 52M   -1 - invalid
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteHoscType(int hosc);
	LINKAGE int EFUSE_ReadHoscType(int* hosc);

	//Function:	Read/Write secure boot
	//Param:	hash: hash key buffer poiter
	//			Read len: equal or more than 32
	//			Write len: 32 only
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteScrBoot(char* hash, int len);
	LINKAGE int EFUSE_ReadScrBoot(char* hash, int len);

	//Function:	Read/Write DCXO trim
	//Param:	value: DCXO value
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteDcxoTrim(char value);
	LINKAGE int EFUSE_ReadDcxoTrim(char* value);

	//Function:	Read/Write POUT CAL
	//Param:	rfCal: POUT CAL buffer
	//			Read len: equal or more than 3
	//			Write len: 3 only
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WritePoutCal(char* rfCal, int len);
	LINKAGE int EFUSE_ReadPoutCal(char* rfCal, int len);

	//Function:	Read/Write MAC address
	//Param:	mac: MAC address buffer
	//			Read len: equal or more than 6
	//			Write len: 6 only
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteMacAddr(char* mac, int len);
	LINKAGE int EFUSE_ReadMacAddr(char* mac, int len);

	//Function:	Read/Write Chip ID
	//Param:	chipId: Chip ID buffer
	//			Read len: equal or more than 16
	//			Write len: 16 only
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteChipId(char* chipId, int len);
	LINKAGE int EFUSE_ReadChipId(char* chipId, int len);

	//Function:	Read/Write user area data
	//Param:	data: data buffer
	//			Read startAddr: 0 to 600
	//			Write startAddr: 0 to 600
	//			Read len: 1 to 601
	//			Write len: 1 to 601
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteUserArea(char* data, int startAddr, int len);
	LINKAGE int EFUSE_ReadUserArea(char* data, int startAddr, int len);

	//Function:	Read/Write DCXO trim0
	//Param:	value: DCXO trim0 value
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteDcxoTrim0(char value);
	LINKAGE int EFUSE_ReadDcxoTrim0(char* value);

/************************************************************
*                         872 use                           *
************************************************************/
	//Function:	Read/Write user area data
	//Param:	data: data buffer
	//			Read startAddr: 0 to 351
	//			Write startAddr: 0 to 351
	//			Read len: 1 to 352
	//			Write len: 1 to 352
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteUserArea872(char* data, int startAddr, int len);
	LINKAGE int EFUSE_ReadUserArea872(char* data, int startAddr, int len);

/************************************************************
*                          709 use                          *
************************************************************/
	//Function:	Read/Write boot mode
	//Param:	value: boot mode value
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteBootMode(char value);
	LINKAGE int EFUSE_ReadBootMode(char* value);

	//Function:	Read/Write level protection
	//Param:	value: level protection value
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteLevelProtection(char value);
	LINKAGE int EFUSE_ReadLevelProtection(char* value);

	//Function:	Read/Write encode BD address
	//Param:	value: encode BD address value
	//			Read len: equal or more than 6
	//			Write len: 6 only
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteEncodeBdAddr(char* addr, int len);
	LINKAGE int EFUSE_ReadEncodeBdAddr(char* addr, int len);

	//Function:	Read/Write secure boot
	//Param:	value: secure boot value
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteSecureBoot709(char value);
	LINKAGE int EFUSE_ReadSecureBoot709(char* value);

	//Function:	Read/Write public key hash
	//Param:	value: public key hash value
	//			Read len: equal or more than 32
	//			Write len: 32 only
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WritePublicKeyHash(char* key, int len);
	LINKAGE int EFUSE_ReadPublicKeyHash(char* key, int len);

	//Function:	Read/Write key 1 error bit number
	//Param:	value: key 1 error bit number value
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_ReadKey1ErrBitNo(char* value);

	//Function:	Read/Write key 2 error bit number
	//Param:	value: key 2 error bit number value
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_ReadKey2ErrBitNo(char* value);

	//Function:	Read/Write chip ID
	//Param:	value: chip ID value
	//			Read len: equal or more than 16
	//			Write len: 16 only
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_ReadChipId709(char* chipId, int len);

	//Function:	Read/Write MAC address
	//Param:	value: MAC address value
	//			Read len: equal or more than 6
	//			Write len: 6 only
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteMacAddr709(char* mac, int len);
	LINKAGE int EFUSE_ReadMacAddr709(char* mac, int len);

	//Function:	Read/Write user area
	//Param:	value: user area value
	//			Read startAddr: 0 to 423
	//			Write startAddr: 0 to 423
	//			Read len: 1 to 424
	//			Write len: 1 to 424
	//Return:	0 - Success		1 - Failed
	LINKAGE int EFUSE_WriteUserArea709(char* data, int startAddr, int len);
	LINKAGE int EFUSE_ReadUserArea709(char* data, int startAddr, int len);


#ifdef __cplusplus
}
#endif

#endif // #ifndef _EFUSE_API_H_