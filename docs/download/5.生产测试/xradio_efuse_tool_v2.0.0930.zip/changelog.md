Efuse tool version:2.0.0930
* 使用下拉框进行芯片选择
* XR872/XR808芯片界面增加 DCXO TRIM 和 POUT CAL 