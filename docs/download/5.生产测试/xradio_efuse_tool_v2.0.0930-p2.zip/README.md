# XRadio Efuse Tool

> XRadio Efuse Tool是深圳芯之联科技有限公司 (Xradio Technology) 用于其芯片读写efuse区域的工具
>
> 支持芯片：XR808系列芯片、XR872系列芯片。
> 使用说明：目前提供windows端的dll库文件以及示例demo程序，详细使用请咨询相关FAE
> 版本说明：请查看[ChangeLog.md](./ChangeLog.md)
