﻿Efuse api version:2.2
* 修改打开串口时关闭RTS/DTR功能

Efuse api version:2.1
* 增加可选的串口baud参数配置，默认115200

Efuse cli tool version:1.1.0
* 增加 HOSC/POUT CAL/SCR BOOT/CHIP ID/USER AREA 等区域的读写
* 增加帮助信息等

Efuse tool version:2.0.0930
* 使用下拉框进行芯片选择
* XR872/XR808芯片界面增加 DCXO TRIM 和 POUT CAL 