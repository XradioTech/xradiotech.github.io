/*
 * Copyright (C) 2017 XRADIO TECHNOLOGY CO., LTD. All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *    1. Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the
 *       distribution.
 *    3. Neither the name of XRADIO TECHNOLOGY CO., LTD. nor the names of
 *       its contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdio.h>
#include <stdint.h>
#include "common/framework/platform_init.h"
#include "audio/reverb/mixer.h"
#include "audio/reverb/resample.h"

#include "audio/pcm/audio_pcm.h"
#include "audio/manager/audio_manager.h"

#include "driver/chip/hal_def.h"
#include "driver/chip/hal_flashctrl.h"
#include "driver/chip/hal_flash.h"
#include "driver/chip/flashchip/flash_chip.h"

#include "fs/fatfs/ff.h"
#include "common/framework/fs_ctrl.h"

#define FLASH_OPEN_TIMEOUT			(5000)
#define PCM_FLASH_ADDR				(1000 * 1024 + 64)
#define PCM_FLASH_LEN				(800 * 1024)
#define PCM_FRAME_LEN				(4 * 1024)

struct PcmConfig {
	unsigned int channel;
	unsigned int rate;
};

static resample_info res_info;
static struct PcmConfig output_config;
static struct PcmConfig init_config;
static struct PcmConfig input_config = {1, 44100};

FRESULT res;    
FIL fp;

int resample_process(struct PcmConfig *input_config, void *inData, int len)
{
	unsigned int channel = input_config->channel;
	unsigned int rate = input_config->rate;
	void *data_ptr = inData;
	int dataLen = len;
	int has_resample = 0;
	resample_info *pinfo = &res_info;
	unsigned int writenum = 0;

	/* convert channel */
	if (output_config.channel != channel) {
		/* infact, we only support convert 2 channels to 1 channels */
		char *src_data[2];
		src_data[0] = (char *)data_ptr;
		src_data[1] = NULL;
		mixer_process(src_data, 2, (char *)data_ptr, dataLen);
		channel = channel / 2;
		dataLen = dataLen / 2;
	}

	/* convert sample rate */
	if (output_config.rate != rate) {
		has_resample = 1;

		if (init_config.channel != channel || init_config.rate != rate) {
			pinfo->BitsPerSample = 16;
			pinfo->in_SampleRate = rate;
			pinfo->NumChannels = channel;
			pinfo->out_SampleRate = output_config.rate;
			resample_init(pinfo);
			init_config.channel = channel;
			init_config.rate = rate;
		}
		resample(pinfo, (short*)data_ptr, dataLen);

		data_ptr = (uint8_t*)pinfo->out_buffer;
		dataLen = pinfo->out_frame_indeed * (pinfo->BitsPerSample / 8) * pinfo->NumChannels;
		printf("resample translate output datalen = %d\r\n", dataLen);
		res = f_write(&fp, data_ptr, dataLen, &writenum);
		if (res != FR_OK) {
			printf("[FATFS] fatfs write data failed!\r\n");
			return -1;
		}
	}

	printf("new pcm data ptr is:%p, new pcm data len is:%u\n", data_ptr, dataLen);

	if (has_resample) {
		resample_release(pinfo);
	}
	return 0;
}

static uint8_t pcm_data_buf[PCM_FRAME_LEN];
void resample_demo(void)
{
	int pcm_datalen = PCM_FLASH_LEN;
	int addr = 0;
	int datalen;
	
	if (HAL_Flash_Open(0, FLASH_OPEN_TIMEOUT) != HAL_OK) {
		printf("open %d fail\n", 0);
	}

	while (pcm_datalen) {
		if (pcm_datalen >= PCM_FRAME_LEN) {
			datalen = PCM_FRAME_LEN;
		} else {
			datalen = pcm_datalen;
		}
		
		if (HAL_OK != HAL_Flash_Read(0, addr+PCM_FLASH_ADDR, pcm_data_buf, datalen)) {
			break;
		}
		resample_process(&input_config, pcm_data_buf, datalen);
		pcm_datalen -= PCM_FRAME_LEN;
		addr += PCM_FRAME_LEN;
	}
	HAL_Flash_Close(0);
	f_close(&fp);
	printf("[FATFS] fs close \r\n");
	if (fs_ctrl_unmount(FS_MNT_DEV_TYPE_SDCARD, 0) != 0) {
		printf("[FATFS] failed to mount: error\n");
	}
}

int main(void)
{
	platform_init();

	output_config.channel = 1;
	output_config.rate = 16000;

	init_config.channel = 0;
	init_config.rate = 0;

	if (fs_ctrl_mount(FS_MNT_DEV_TYPE_SDCARD, 0) != 0) {
		while (1) {
			printf("[FATFS] failed to mount: error\n");
			OS_MSleep(3000);
		}
	}

	if (f_open(&fp, "resample.pcm", FA_OPEN_ALWAYS | FA_READ | FA_WRITE) != FR_OK) {
		while (1) {
			printf("[FATFS] fialed to f_open:error\r\n");      
			OS_MSleep(3000);
		}
	}

	resample_demo();
	
	return 0;
}
