/*
 * Copyright (C) 2017 XRADIO TECHNOLOGY CO., LTD. All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *    1. Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the
 *       distribution.
 *    3. Neither the name of XRADIO TECHNOLOGY CO., LTD. nor the names of
 *       its contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common/framework/platform_init.h"
#include "audio_player.h"
#include "soundStreamControl.h"
#include "audio/pcm/audio_pcm.h"
#include "audio/manager/audio_manager.h"
#include "kernel/os/os.h"
#include "fs/fatfs/ff.h"
#include "common/framework/fs_ctrl.h"
#include "common/apps/player_app.h"

#define AUDIO_CARD					AUDIO_SND_CARD_DEFAULT
#define AUDIO_SAMPLERATE			(16000)
#define AUDIO_CHANNELS				(1)
#define AUDIO_PERIOD_SIZE			(1024)
#define AUDIO_PERIOD_COUNT			(2)

static player_base *player = NULL;
static OS_Thread_t player_thread;
static OS_Semaphore_t sem;

struct pcmContext {
	SoundStreamCtrl ssc;
	void *buffer;
	unsigned int buf_len;
};

struct pcmContext pcmdata;

int cedarx_pcm_stream()
{
	struct SscPcmConfig config;
	config.channels = 1;
	config.rate = 16000;

	printf("cedarx_pcm_stream config\r\n");
	
	pcmdata.buf_len = AUDIO_CHANNELS * AUDIO_PERIOD_COUNT * AUDIO_PERIOD_SIZE;
	pcmdata.buffer = malloc(pcmdata.buf_len);
	if (pcmdata.buffer == NULL) {
		printf("malloc pcmdata failed!\r\n");
		return -1;
	}
	pcmdata.ssc = snd_stream_create(STREAM_TYPE_CUSTOMER);
	if (pcmdata.ssc == NULL) {
		free(pcmdata.buffer);
		printf("customer stream create failed!\r\n");
		return -1;
	}
	
	player->pause(player);
	
	snd_stream_control(pcmdata.ssc, STREAM_TYPE_CUSTOMER, STREAM_CMD_SET_OUTPUT_CONFIG, &config);
	snd_stream_open(pcmdata.ssc, STREAM_TYPE_CUSTOMER);
	
	player->resume(player);
	
	return 0;
}
static uint8_t player_state=0;
static void play_task_callback(player_events event, void *data, void *arg)
{
	switch (event) {
	case PLAYER_EVENTS_MEDIA_PREPARED:
		break;
	case PLAYER_EVENTS_MEDIA_STOPPED:
		break;
	case PLAYER_EVENTS_MEDIA_ERROR:
		printf("error occur\n");
		OS_SemaphoreRelease(&sem);
		break;
	case PLAYER_EVENTS_MEDIA_PLAYBACK_COMPLETE:
		printf("media play is complete\n");
		OS_SemaphoreRelease(&sem);
		break;
	default:
		break;
	}
}

static void play_task(void *arg)
{
	OS_Status ret;

	ret = OS_SemaphoreCreate(&sem, 0, OS_SEMAPHORE_MAX_COUNT);
	if (ret != OS_OK) {
		printf("sem create fail\n");
		return;
	}

	player = player_create();
	if (player == NULL) {
		printf("player create fail.\n");
		OS_SemaphoreDelete(&sem);
		return;
	}
	
	//struct SscPcmConfig config;
	//config.channels = 1;
	//config.rate = 16000;
	//player->control(player, PLAYER_CMD_SET_OUTPUT_CONFIG, &config);
	player->setvol(player, 15);

	player_state = 1;
	while (player_state) {
		player->set_callback(player, play_task_callback, NULL);
		player->play(player, "file://record/1.mp3");

		OS_SemaphoreWait(&sem, OS_WAIT_FOREVER);
		player_state = 0;

		snd_stream_close(pcmdata.ssc, STREAM_TYPE_CUSTOMER);
		player->stop(player);
		OS_Sleep(10);
	}

	OS_SemaphoreDelete(&sem);
	player_destroy(player);

	OS_ThreadDelete(&player_thread);
}

int background_music_start()
{
	if (OS_ThreadCreate(&player_thread,
                        "player_task",
                        play_task,
                        NULL,
                        OS_THREAD_PRIO_APP,
                        4096) != OS_OK) {
		printf("thread create fail.exit\n");
		return -1;
	}
	return 0;
}

int main(void)
{
	platform_init();

	if (fs_ctrl_mount(FS_MNT_DEV_TYPE_SDCARD, 0) != 0) {
		printf("mount fail\n");
		return -1;
	}

	printf("start demo cedarx customer stream...\r\n");
	
	background_music_start();
	OS_MSleep(50);
	cedarx_pcm_stream();
	
	return 0;
}
