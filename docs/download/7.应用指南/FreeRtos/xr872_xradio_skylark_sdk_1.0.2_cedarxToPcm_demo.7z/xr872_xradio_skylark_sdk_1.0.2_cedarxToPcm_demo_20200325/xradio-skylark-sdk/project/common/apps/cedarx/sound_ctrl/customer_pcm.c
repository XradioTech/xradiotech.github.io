/*
 * Copyright (C) 2017 XRADIO TECHNOLOGY CO., LTD. All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *    1. Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the
 *       distribution.
 *    3. Neither the name of XRADIO TECHNOLOGY CO., LTD. nor the names of
 *       its contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifdef __CONFIG_XPLAYER

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "audio/pcm/audio_pcm.h"
#include "audio/manager/audio_manager.h"
#include "soundStream.h"
#include "fs/fatfs/ff.h"
#include "common/framework/fs_ctrl.h"

#define SUPPORT_FIXED_OUTPUT_CONFIG

#ifdef SUPPORT_FIXED_OUTPUT_CONFIG
#include "audio/reverb/mixer.h"
#include "audio/reverb/resample.h"
#endif

#ifdef SUPPORT_FIXED_OUTPUT_CONFIG
#define DEFAULT_OUTPUT_SAMPLE_RATE		(16000)
#define DEFAULT_OUTPUT_CHANNEL			(1)
#endif

#define AUDIO_PERIOD_SIZE				1024
#define AUDIO_PERIOD_COUNT				2

struct CustomerPcmConfig {
    unsigned int  channels;
    unsigned int  rate;
};

typedef struct CustomerContext {
    SoundStreamT base;
    struct pcm_config input_config;
#ifdef SUPPORT_FIXED_OUTPUT_CONFIG
    struct CustomerPcmConfig output_cfg;
    struct pcm_config *output_config;
    resample_info res_info;
    unsigned int rate;
    unsigned int channel;
#endif
} CustomerContext;

FRESULT result;
FIL fp;

static int customer_pcm_open(SoundStreamT *stream)
{
	CustomerContext *context = (CustomerContext *)stream;

	f_unlink("record/CdxToPcm.pcm");
    result = f_open(&fp, "record/CdxToPcm.pcm", FA_OPEN_ALWAYS | FA_WRITE | FA_READ);
    if (result != FR_OK) {
		printf("customer_pcm_open record/CdxToPcm.pcm open failed\r\n");
        return -1;
    }
	
	printf("customer_pcm_open output_config context = %p, line = %d\r\n", context->output_config, __LINE__);
	
#ifdef SUPPORT_FIXED_OUTPUT_CONFIG
    if (context->output_config) {
        if (context->output_cfg.channels == 0) {
            context->output_config->channels = context->input_config.channels;
        }
        if (context->output_cfg.rate == 0) {
            context->output_config->rate = context->input_config.rate;
        }

		printf("customer_pcm_open output_config context channel = %d\r\n", context->output_cfg.channels);
		printf("customer_pcm_open output_config context rate = %d\r\n", context->output_cfg.rate);
		
        return snd_pcm_open(AUDIO_SND_CARD_DEFAULT, PCM_OUT, context->output_config);
    }
#endif

	printf("customer_pcm_open input_config context = %p\r\n", &(context->input_config));
	printf("customer_pcm_open input_config context channel = %d\r\n", context->input_config.channels);
	printf("customer_pcm_open input_config context rate = %d\r\n", context->input_config.rate);

	return snd_pcm_open(AUDIO_SND_CARD_DEFAULT, PCM_OUT, &(context->input_config));
}

static int customer_pcm_close(SoundStreamT *stream)
{
	printf("customer_pcm_close, line=%d\r\n", __LINE__);
	f_close(&fp);
	
    return snd_pcm_close(AUDIO_SND_CARD_DEFAULT, PCM_OUT);
}

static int customer_pcm_flush(SoundStreamT *stream)
{
    CustomerContext *context = (CustomerContext *)stream;

	printf("customer_pcm_flush line=%d\r\n", __LINE__);
	
#ifdef SUPPORT_FIXED_OUTPUT_CONFIG
    if (context->output_config) {
        if (context->output_cfg.channels == 0) {
            context->output_config->channels = context->input_config.channels;
        }
        if (context->output_cfg.rate == 0) {
            context->output_config->rate = context->input_config.rate;
        }
        return snd_pcm_flush(AUDIO_SND_CARD_DEFAULT);
    }
#endif

    return snd_pcm_flush(AUDIO_SND_CARD_DEFAULT);
}

static int customer_pcm_write(SoundStreamT *stream, struct SscPcmConfig *config, void *data, unsigned int count)
{
	uint32_t write_len;

#ifdef SUPPORT_FIXED_OUTPUT_CONFIG
    int has_resample = 0;
    resample_info *res_info;
#endif
    void *outData = data;
    unsigned int dataLen = count;
    CustomerContext *context = (CustomerContext *)stream;
	
	printf("customer_pcm_write datasize=%d, line=%d\r\n", count, __LINE__);
	//f_write(&fp, data, count, &write_len);
	
#ifdef SUPPORT_FIXED_OUTPUT_CONFIG
    res_info = &context->res_info;
    if (context->output_config) {
        /* convert channel */
        if ((context->output_cfg.channels == 0) || (context->output_cfg.channels == context->input_config.channels)) {
			printf("customer_pcm_write output channel...%d\r\n", __LINE__);
			context->output_config->channels = context->input_config.channels;
        } else { /* request output channel is not equal to channel of this audio */
            /* infact, we only support convert 2 channels to 1 channels */
            char *src_data[2];
            src_data[0] = (char *)outData;
            src_data[1] = NULL;
            mixer_process(src_data, 2, (char *)outData, dataLen);
            dataLen = dataLen / 2;
        }
		printf("customer_pcm_write convert...%d\r\n", __LINE__);
        /* convert sample rate */
        if ((context->output_cfg.rate == 0) || (context->output_cfg.rate == context->input_config.rate)) {
            context->output_config->rate = context->input_config.rate;
			printf("customer_pcm_write output rate = %d...%d\r\n", context->output_config->rate, __LINE__);
        } else {
            unsigned int out_channel;
            unsigned int in_rate;

            has_resample = 1;
            out_channel = context->output_config->channels;
            //in_rate = context->input_config.rate;
            printf("context->input_config.rate = %d, line = %d\r\n", context->input_config.rate, __LINE__);
			printf("config->input_config.rate = %d, line = %d\r\n", config->rate, __LINE__);
            in_rate = config->rate;
            if (context->channel != out_channel || context->rate != in_rate) {
                res_info->BitsPerSample = 16;
                res_info->in_SampleRate = in_rate;
                res_info->NumChannels = out_channel;
                res_info->out_SampleRate = context->output_config->rate;
                resample_init(res_info);
                context->channel = out_channel;
                context->rate = in_rate;
            }
            resample(res_info, (short*)outData, dataLen);
            outData = res_info->out_buffer;
            dataLen = res_info->out_frame_indeed * (res_info->BitsPerSample / 8) * res_info->NumChannels;
        }

		printf("customer_pcm_write datasize = %d, line=%d\r\n", count, __LINE__);
		f_write(&fp, outData, dataLen, &write_len);
        snd_pcm_write(AUDIO_SND_CARD_DEFAULT, outData, dataLen);

        if (has_resample) {
            resample_release(res_info);
        }
        return count;
    }
#endif

	printf("customer_pcm_write datasize = %d, line=%d\r\n", count, __LINE__);
    return snd_pcm_write(AUDIO_SND_CARD_DEFAULT, outData, dataLen);
}

static int customer_pcm_read(SoundStreamT *stream, void *data, unsigned int count)
{
	CustomerContext *context = (CustomerContext *)stream;
	
	printf("customer_pcm_read datasize=%d, line=%d\r\n", count, __LINE__);
	
#ifdef SUPPORT_FIXED_OUTPUT_CONFIG
    if (context->output_config) {
        if (context->output_cfg.channels == 0) {
            context->output_config->channels = context->input_config.channels;
        }
        if (context->output_cfg.rate == 0) {
            context->output_config->rate = context->input_config.rate;
        }
        return snd_pcm_read(AUDIO_SND_CARD_DEFAULT, data, count);
    }
#endif
    return snd_pcm_read(AUDIO_SND_CARD_DEFAULT, data, count);
}

static int customer_pcm_ioctl(SoundStreamT *stream, SoundStreamCmd cmd, void *param)
{
    struct SscPcmConfig *config;
    CustomerContext *context = (CustomerContext *)stream;

	printf("customer_pcm_ioctl, cmd = %d, line=%d\r\n", cmd, __LINE__);
	
    switch (cmd) {
    case STREAM_CMD_SET_CONFIG:
        config = (struct SscPcmConfig *)param;
        context->input_config.channels     = config->channels;
        context->input_config.rate         = config->rate;
        context->input_config.format       = PCM_FORMAT_S16_LE;
        context->input_config.period_count = AUDIO_PERIOD_COUNT;
        context->input_config.period_size  = AUDIO_PERIOD_SIZE;
        break;
#ifdef SUPPORT_FIXED_OUTPUT_CONFIG
    case STREAM_CMD_SET_OUTPUT_CONFIG:
        config = (struct SscPcmConfig *)param;
        if (config->channels > 1) {
            printf("invalid output config. channel:%u\n", config->channels);
            break;
        }

        if (context->output_config == NULL) {
            context->output_config = (struct pcm_config *)malloc(sizeof(struct pcm_config));
            if (context->output_config == NULL) {
                break;
            } else {
				printf("[customer_pcm_ioctl] context->output_config %p \r\n", context->output_config);
			}
        }
        context->output_cfg.channels = config->channels;
        context->output_cfg.rate     = config->rate;
        context->output_config->channels     = config->channels;
        context->output_config->rate         = config->rate;
        context->output_config->format       = PCM_FORMAT_S16_LE;
        context->output_config->period_count = AUDIO_PERIOD_COUNT;
        context->output_config->period_size  = AUDIO_PERIOD_SIZE;
        break;
    case STREAM_CMD_CLEAR_OUTPUT_CONFIG:
        free(context->output_config);
        context->output_config = NULL;
        break;
#endif
    default:
        break;
    }
    return 0;
}

static const struct SoundStreamOpsS customerStreamOps =
{
    .soundOpen  = customer_pcm_open,
    .soundClose = customer_pcm_close,
    .soundWrite = customer_pcm_write,
    .soundRead  = customer_pcm_read,
    .soundFlush = customer_pcm_flush,
    .soundIoctl = customer_pcm_ioctl,
};

static SoundStreamT * customer_pcm_create(void)
{
    CustomerContext *context;

	printf("customer_pcm_create line %d\r\n", __LINE__);
    context = (CustomerContext *)malloc(sizeof(CustomerContext));
    if (context == NULL) {
		printf("customer_pcm_create failed 119L\r\n");
        return NULL;
    }
    memset(context, 0, sizeof(CustomerContext));

#if 0//def SUPPORT_FIXED_OUTPUT_CONFIG
	context->output_cfg.channels			= DEFAULT_OUTPUT_CHANNEL;
	context->output_cfg.rate				= DEFAULT_OUTPUT_SAMPLE_RATE;
	context->output_config.channels		= DEFAULT_OUTPUT_CHANNEL;
	context->output_config.rate			= DEFAULT_OUTPUT_SAMPLE_RATE;
	context->output_config.format			= PCM_FORMAT_S16_LE;
	context->output_config.period_count	= AUDIO_PERIOD_COUNT;
	context->output_config.period_size		= AUDIO_PERIOD_SIZE;
#endif

	printf("customer_pcm_create context = %p, line=%d\r\n", context, __LINE__);
    context->base.ops = &customerStreamOps;
    return &context->base;
}

static void customer_pcm_destroy(SoundStreamT * stream)
{
    CustomerContext *context = (CustomerContext *)stream;
#ifdef SUPPORT_FIXED_OUTPUT_CONFIG
    free(context->output_config);
#endif
    free(context);
}

const struct SoundStreamCreatorS CustomerStreamCtor =
{
    .create  = customer_pcm_create,
    .destroy = customer_pcm_destroy,
};

#endif
