#ifndef __PWM_AUDIO_TEST_H__
#define __PWM_AUDIO_TEST_H__

#ifdef __cplusplus
extern "C" {
#endif

int pwm_player_task_create(void);

#ifdef __cplusplus
}
#endif

#endif /* __PWM_AUDIO_TEST_H__ */
