#ifndef __PWM_PALYER_H__
#define __PWM_PALYER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stdio.h"
#include "stdint.h"

#define PWM_PLAYER_DBG_ON				0
#define PWM_PLAYER_WRN_ON				0
#define PWM_PLAYER_ERR_ON				1

#define PWM_PLAYER_SYSLOG				printf

#define PWM_PLAYER_LOG(flags, fmt, arg...)	\
    do {									\
        if (flags)							\
            PWM_PLAYER_SYSLOG(fmt, ##arg);	\
    } while (0)

#define PWM_PLAYER_DBG(fmt, arg...)	\
    PWM_PLAYER_LOG(PWM_PLAYER_DBG_ON, "[PWM_PLAYER DBG] "fmt, ##arg)

#define PWM_PLAYER_WRN(fmt, arg...)	\
    PWM_PLAYER_LOG(PWM_PLAYER_WRN_ON, "[PWM_PLAYER WRN] "fmt, ##arg)

#define PWM_PLAYER_ERR(fmt, arg...)								\
    do {														\
		PWM_PLAYER_LOG(PWM_PLAYER_ERR_ON, "[PWM_PLAYER ERR] %s():%d, "fmt,	\
               __func__, __LINE__, ##arg); \
    } while (0)


typedef void (*pwm_callback_fun)(void);

typedef enum
{
	SAMPLERATE_8K	= (uint32_t)8000,
	SAMPLERATE_16K	= (uint32_t)16000
}pwm_samplerate_t;

typedef enum
{
	SAMPLEBIT_8BIT	= (uint8_t)8,
	SAMPLEBIT_16BIT	= (uint8_t)16
}pwm_samplebit_t;

typedef struct
{
	pwm_samplerate_t samplerate;
	pwm_samplebit_t samplebit;
}pwm_player_cfg_t;

typedef enum
{
	VOL_LEVEL_1		= (uint8_t)0,
	VOL_LEVEL_2		= (uint8_t)1,
	VOL_LEVEL_3		= (uint8_t)2,
	VOL_LEVEL_4		= (uint8_t)3,
	VOL_LEVEL_5		= (uint8_t)4
}pwm_player_vol_level_t;

int pwm_player_init(pwm_player_cfg_t *cfg);
void pwm_player_deinit(void);
int pwm_player_start(uint8_t *pcm_data, uint32_t pcm_datalen, pwm_callback_fun cb);
int pwm_player_stop(void);
int pwm_player_set_vol(pwm_player_vol_level_t vol);
int pwm_player_get_vol(void);


#ifdef __cplusplus
}
#endif

#endif /* __PWM_PALYER_H__ */
