#  演示工程

> pwm_player_demo用于演示基于硬件PWM(IO复用)播放PCM音频输出功能。

---

## 适用平台

> 本工程适用以下芯片类型：
>
> 1. XR872系列芯片

> 本工程适用SDK版本：XR872SDK V1.0.2
>
> 获取SDK链接：
> https://github.com/XradioTech/xradio-skylark-sdk.git

> XRadio Wireless MCU芯片和评估板的更多信息可在以下地址获取：
> https://docs.xradiotech.com

## 工程配置

> localconfig.mk：
> * __CONFIG_WLAN_STA: 使用STA模式时将此项置为y
> * __CONFIG_WLAN_STA_WPS： 使用STA模式并且使用WPS功能时，将此项置为y，注意不能与__CONFIG_WLAN_STA同时置为y
> * __CONFIG_WLAN_AP： 使用AP模式时将此项置为y
>
> Makefile：
> * IMAGE_CFG: 选择工程的flash布局文件。如无，则使用默认配置
> * LINKER_SCRIPT: 选择工程的ld文件。如无，则使用默认ld文件
> * PRJ_BOARD：必选项，选择板子的板级配置路径
>
> board_config.h
> * N/A
>
> board_config.c
> * N/A
>
> prj_config.h
>
> * PRJCONF_CONSOLE_EN: 必选项，配置使用控制台
> * PRJCONF_NET_EN: 必选项，配置使用网络

## 模块依赖

> 1.PWM 模块
> 2.Timer 硬件定时器模块


---

## 工程说明

> 1.PWM播放PCM支持8K8Bit和16K8Bit采样率音频，暂不支持16Bit PCM音频播放
> 2.默认分配PWM和Timer时钟使用外部晶振时钟，demo使用40Mh晶振
> 3.硬件特征配置可以在pwm_player.c修改外部晶振频率、定时器、PWM通道。

### 操作说明

> 1.目前使用XR872 PWM0通道即PA8输出，在没有外接功放情况下可以将PA8接到耳机输入端，硬件GND接耳机的GND, 以PA8 IO对应PWM功能硬件模拟PCM数据播放输出。
> 2.更新src\driver\chip\hal_pwm.c补丁并编译pwm_player_demo固件，在固件1020K以及1500K位置合成16K8bit.bin和8K8bit.pcm两个PCM音频，demo演示从flash读
取对应的PCM音频通过PWM硬件输出。

> https://github.com/XradioTech/xradiotech-wiki

### 控制命令

> N/A

### 代码结构
```
#本工程
.
├── gcc
│   ├── localconfig.mk          # 本工程的配置选项，主要用于覆盖默认全局配置
│   └── Makefile                # 本工程的编译规则，如ld文件、image.cfg、board_config.h等文件指定，可覆盖默认配置
├── image
│   └── xr872
│       └── image.cfg           # 本工程的镜像布局配置
├── pwm_player                  # PWM PLAYER播放器驱动，控制PCM音频输出
├── main.c                      # 本工程的入口，完成平台初始化
├── command.c                   # 本工程的控制台命令入口
├── command.h
├── prj_config.h                # 本工程的配置选项，主要用于功能的选择。
├── pwm_audio_test.c            # 本工PWM Player播放PCM操作示例
├── pwm_audio_test.h            # 本工PWM Player播放PCM操作示例头文件接口
└── readme.md                   # 本工程的说明文档

#本工程用到XRadio SDK的其他配置文件
.
└── project
│    └── common
│        └── board
│            └── xradio_evb             #本工程在Makefile中指定使用xradio_evb的板级配置
│                ├── board_config.h     #本工程的板级配置，
│                └── board_config.c     #本工程的板级pin mux的配置。
└── src
     └── driver
            └── chip
                  └──hal_pwm.c          #补丁修改该文件，允许在中断中修改PWM占空比
```
### 代码流程

> 1. N/A


---


## 常见问题

> N/A
