
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "kernel/os/os.h"

#include "driver/chip/hal_flash.h"
#include "image/flash.h"
#include "pwm_player/pwm_player.h"


#define PWM_PLAYER_TASK_STACK_SIZE		(2 * 1024)
static OS_Thread_t pwm_player_task_handler;
static OS_Semaphore_t pwm_player_complete_sem;

#define FLASH_PCM_8K8B_DATA_SIZE		(200 * 1024)
#define FLASH_PCM_8K8B_DATA_START		(1020 * 1024 + 64)
#define FLASH_PCM_8K8B_DATA_END			(FLASH_PCM_8K8B_DATA_START + FLASH_PCM_8K8B_DATA_SIZE)

#define FLASH_PCM_16K8B_DATA_SIZE		(200 * 1024)
#define FLASH_PCM_16K8B_DATA_START		(1500 * 1024 + 64)
#define FLASH_PCM_16K8B_DATA_END		(FLASH_PCM_16K8B_DATA_START + FLASH_PCM_16K8B_DATA_SIZE)


#define AUDIO_PCM_DATA_SIZE				(200 * 1024)
uint8_t audio_pcm_data_arr[AUDIO_PCM_DATA_SIZE];


void pwm_player_callback(void)
{
	printf("player end\r\n");
	OS_SemaphoreRelease(&pwm_player_complete_sem);
}

void pwm_player_task(void *pvParameters)
{
	static uint8_t playlist_index = 0;
	pwm_player_cfg_t player_cfg;

	printf("[PWM PLAYER TASK] play start!\r\n");

	memset(audio_pcm_data_arr, 0, AUDIO_PCM_DATA_SIZE);
	flash_read(0, FLASH_PCM_16K8B_DATA_START, audio_pcm_data_arr, FLASH_PCM_16K8B_DATA_SIZE);
	
	memset(&player_cfg, 0, sizeof(pwm_player_cfg_t));
	player_cfg.samplebit	= SAMPLEBIT_8BIT;
	player_cfg.samplerate	= SAMPLERATE_16K;
	pwm_player_init(&player_cfg);
	pwm_player_start(audio_pcm_data_arr, FLASH_PCM_16K8B_DATA_SIZE, pwm_player_callback);
	pwm_player_set_vol(VOL_LEVEL_2);
	
	while (1) {
		if (OS_OK == OS_SemaphoreWait(&pwm_player_complete_sem, 1000)) {
			if (playlist_index == 0) {
				playlist_index++;

				OS_MSleep(2000);
				printf("[PWM PLAYER TASK] play next\r\n");

				memset(audio_pcm_data_arr, 0, AUDIO_PCM_DATA_SIZE);
				flash_read(0, FLASH_PCM_8K8B_DATA_START, audio_pcm_data_arr, FLASH_PCM_8K8B_DATA_SIZE);
				
				pwm_player_deinit();
				player_cfg.samplebit	= SAMPLEBIT_8BIT;
				player_cfg.samplerate	= SAMPLERATE_8K;
				pwm_player_init(&player_cfg);
				pwm_player_start(audio_pcm_data_arr, FLASH_PCM_8K8B_DATA_SIZE, pwm_player_callback);
			} else {
				playlist_index = 2;
				pwm_player_deinit();
			}
		}
	}
}


int pwm_player_task_create(void)
{
	OS_MSleep(100);

	OS_SemaphoreCreateBinary(&pwm_player_complete_sem);
	
	if (OS_ThreadCreate(&pwm_player_task_handler,
						"pwm_player_task",
						pwm_player_task,
						NULL,
						OS_THREAD_PRIO_APP,
						PWM_PLAYER_TASK_STACK_SIZE) != OS_OK) {
		printf("parser task create error\n");
		return -1;
	}
	
	printf("pwm player thread create success, handler = 0x%x\n", (uint32_t)pwm_player_task_handler.handle);
	return 0;
}

