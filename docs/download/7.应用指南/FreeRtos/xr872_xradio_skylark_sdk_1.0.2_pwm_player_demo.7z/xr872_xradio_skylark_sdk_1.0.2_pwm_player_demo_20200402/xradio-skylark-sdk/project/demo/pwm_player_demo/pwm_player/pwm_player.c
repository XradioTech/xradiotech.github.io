#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "driver/chip/hal_timer.h"
#include "driver/chip/hal_pwm.h"
#include "pwm_player.h"


#define SOURCE_CLK_HOSC				40000000

#define USER_TIMERID				TIMER0_ID
#define USER_PWM_CHANNEL			PWM_GROUP0_CH0


typedef enum {
	PWM_PLAYER_OFF	= 0,
	PWM_PLAYER_INIT = 0x10,
	PWM_PLAYER_ON	= 0x20
}pwm_player_state_t;

typedef struct {
	pwm_player_state_t state;
	uint8_t sampleBit;
	uint16_t sampleRate;
	uint32_t pcm_datelen;
	uint32_t pcm_datecnt;
	pwm_callback_fun cb;
	uint8_t *pcm_data;
	uint8_t vol;
}pwm_palyer_t;

static pwm_palyer_t pwm_player_param;


int pwm_player_set_vol(pwm_player_vol_level_t vol)
{
	if (vol >= VOL_LEVEL_5) {
		pwm_player_param.vol = VOL_LEVEL_5;	
	}
	pwm_player_param.vol = vol;

	PWM_PLAYER_DBG("pwm player setvol %d\r\n", pwm_player_param.vol);
	
	return 0;
}

int pwm_player_get_vol(void)
{
	PWM_PLAYER_DBG("pwm player getvol %d\r\n", pwm_player_param.vol);
	
	return pwm_player_param.vol;
}

static int player_pwm_init(pwm_samplebit_t sampleBit)
{
	HAL_Status status = HAL_ERROR;
	PWM_ClkParam clk_param;
	PWM_ChInitParam ch_param;
	int max_duty_ratio = 0;

	clk_param.clk = PWM_CLK_HOSC;
	clk_param.div = PWM_SRC_CLK_DIV_1;

	status = HAL_PWM_GroupClkCfg(USER_PWM_CHANNEL / 2, &clk_param);
	if (status != HAL_OK) {
		PWM_PLAYER_DBG("%s(): %d, PWM group clk config error\n", __func__, __LINE__);
		return -1;
	}

	if (sampleBit == SAMPLEBIT_8BIT) {
		ch_param.hz = SOURCE_CLK_HOSC >> SAMPLEBIT_8BIT;	//8bit support
	} else if (sampleBit == SAMPLEBIT_16BIT) {
		ch_param.hz = SOURCE_CLK_HOSC >> SAMPLEBIT_16BIT;	//16bit not support
		PWM_PLAYER_DBG("PWM not support bit\r\n");
		HAL_PWM_ChDeinit(USER_PWM_CHANNEL);
		return -1;
	} else {
		PWM_PLAYER_DBG("PWM not support bit\r\n");
		HAL_PWM_ChDeinit(USER_PWM_CHANNEL);
		return -1;
	}
	ch_param.mode		= PWM_CYCLE_MODE;
	ch_param.polarity	= PWM_HIGHLEVE;
	max_duty_ratio = HAL_PWM_ChInit(USER_PWM_CHANNEL, &ch_param);
	PWM_PLAYER_DBG("player_pwm_init max_duty_ratio = %d\r\n", max_duty_ratio);
	if (max_duty_ratio == -1) {
		PWM_PLAYER_DBG("%s(): %d, PWM ch init error\n", __func__, __LINE__);
		return -1;
	}

	status = HAL_PWM_ChSetDutyRatio(USER_PWM_CHANNEL, max_duty_ratio / 2);
	if (status != HAL_OK) {
		PWM_PLAYER_DBG("%s(): %d, PWM set duty ratio error\n", __func__, __LINE__);
		return -1;
	}

	return 0;
}

static void player_pwm_deinit(void)
{
	HAL_PWM_EnableCh(USER_PWM_CHANNEL, PWM_CYCLE_MODE, 0);
	HAL_PWM_ChDeinit(USER_PWM_CHANNEL);
}

void player_timer_callback(void *arg)
{
	short pwm_ratio;
	
	if ((pwm_player_param.state & PWM_PLAYER_ON) && (pwm_player_param.pcm_datecnt < pwm_player_param.pcm_datelen)) {
		if (pwm_player_param.sampleBit == SAMPLEBIT_8BIT) {
			pwm_ratio = pwm_player_param.pcm_data[pwm_player_param.pcm_datecnt];
			pwm_ratio = pwm_ratio >> pwm_player_param.vol;
			if (HAL_PWM_ChSetDutyRatio(USER_PWM_CHANNEL, pwm_ratio)) {
				PWM_PLAYER_ERR("PWM radio err\r\n");
			}
			pwm_player_param.pcm_datecnt++;
		} else if (pwm_player_param.sampleBit == SAMPLEBIT_16BIT) {
			
		}
	} else {
		PWM_PLAYER_DBG("play complete\r\n");
		pwm_player_stop();
		if (pwm_player_param.cb != NULL) {
			pwm_player_param.cb();
			pwm_player_param.cb = NULL;
		}
	}
}

static int player_timer_init(pwm_samplerate_t samplerate)
{
	HAL_Status status = HAL_ERROR;
	TIMER_InitParam param;
	
	param.arg			= NULL;
	param.callback		= player_timer_callback;
	param.cfg			= HAL_TIMER_MakeInitCfg(TIMER_MODE_REPEAT, TIMER_CLK_SRC_HFCLK, TIMER_CLK_PRESCALER_1);
	param.isEnableIRQ	= 1;
	if (samplerate == SAMPLERATE_8K) {
		param.period = SOURCE_CLK_HOSC / SAMPLERATE_8K;
	} else if (samplerate == SAMPLERATE_16K) {
		param.period = SOURCE_CLK_HOSC / SAMPLERATE_16K;
	} else {
		PWM_PLAYER_ERR("timer init not support samplerate!\r\n");
		return -1;
	}
	
	status = HAL_TIMER_Init(USER_TIMERID, &param);
	if (status != HAL_OK) {
		PWM_PLAYER_DBG("timer int error %d\n", status);
		return -1;
	}
	
	return 0;
}

static void player_timer_deinit(void)
{
	HAL_TIMER_Stop(USER_TIMERID);
	HAL_TIMER_DeInit(USER_TIMERID);
}

int pwm_player_init(pwm_player_cfg_t *cfg)
{
	memset(&pwm_player_param, 0, sizeof(pwm_palyer_t));
	pwm_player_param.sampleRate	= cfg->samplerate;
	pwm_player_param.sampleBit	= cfg->samplebit;
	pwm_player_param.vol		= VOL_LEVEL_1;
	if (player_pwm_init(pwm_player_param.sampleBit)) {
		PWM_PLAYER_ERR("player init sampleBit not support!\r\n");
		return -1;
	}

	if (player_timer_init(pwm_player_param.sampleRate)) {
		player_pwm_deinit();
		
		PWM_PLAYER_ERR("player init sampleRate not support!\r\n");
		return -1;
	}

	pwm_player_param.state |= PWM_PLAYER_INIT;
	PWM_PLAYER_DBG("player init sucess!\r\n");

	return 0;
}

void pwm_player_deinit(void)
{
	player_timer_deinit();
	player_pwm_deinit();
	memset(&pwm_player_param, 0, sizeof(pwm_player_param));
}

int pwm_player_start(uint8_t *pcm_data, uint32_t pcm_datalen, pwm_callback_fun cb)
{
	if (pwm_player_param.state & PWM_PLAYER_ON) {
		PWM_PLAYER_ERR("player already started!\r\n");
		return -1;
	}
	
	if (pwm_player_param.state != PWM_PLAYER_INIT) {
		PWM_PLAYER_ERR("player start failed!\r\n");
		return -1;
	}
	
	pwm_player_param.pcm_datecnt	= 0;
	pwm_player_param.pcm_datelen	= pcm_datalen;
	pwm_player_param.pcm_data		= pcm_data;
	pwm_player_param.cb				= cb;
	
	if (HAL_PWM_EnableCh(USER_PWM_CHANNEL, PWM_CYCLE_MODE, 1)) {
		PWM_PLAYER_ERR("player start failed!\r\n");
		return -1;
	}

	pwm_player_param.state |= PWM_PLAYER_ON;
	HAL_TIMER_Start(USER_TIMERID);

	PWM_PLAYER_DBG("player begin...\r\n");
	
	return 0;
}

int pwm_player_stop(void)
{
	HAL_TIMER_Stop(USER_TIMERID);
	HAL_PWM_EnableCh(USER_PWM_CHANNEL, PWM_CYCLE_MODE, 0);

	if (pwm_player_param.state & PWM_PLAYER_INIT) {
		pwm_player_param.state = PWM_PLAYER_INIT;
	} else {
		pwm_player_param.state = PWM_PLAYER_OFF;
	}
	pwm_player_param.pcm_datecnt	= 0;
	pwm_player_param.pcm_datelen	= 0;
	pwm_player_param.pcm_data		= NULL;
	//pwm_player_param.cb				= NULL;

	PWM_PLAYER_DBG("player stop!\r\n");
	
	return 0;
}

