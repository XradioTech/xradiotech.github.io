/*
 * Copyright (C) 2017 XRADIO TECHNOLOGY CO., LTD. All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *    1. Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the
 *       distribution.
 *    3. Neither the name of XRADIO TECHNOLOGY CO., LTD. nor the names of
 *       its contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
#include "common/framework/net_ctrl.h"
#include "net_msg.h"


void net_event_ob(uint32_t event, uint32_t data, void *arg)
{	
	uint16_t type;

	type = EVENT_SUBTYPE(event);
	NET_MSG_INF("%s msg (%u, %u)\n", __func__, type, data);

	switch (type) {
		case NET_CTRL_MSG_WLAN_CONNECTED:
			NET_MSG_INF("NET_CTRL_MSG_WLAN_CONNECTED\n");
			break;
		case NET_CTRL_MSG_WLAN_DISCONNECTED:
			NET_MSG_INF("NET_CTRL_MSG_WLAN_DISCONNECTED\n");
			break;
		case NET_CTRL_MSG_WLAN_SCAN_SUCCESS:
			NET_MSG_INF("NET_CTRL_MSG_WLAN_SCAN_SUCCESS\n");
			break;
		case NET_CTRL_MSG_WLAN_SCAN_FAILED:
			NET_MSG_INF("NET_CTRL_MSG_NETWORK_DOWN\n");
			break;
		case NET_CTRL_MSG_WLAN_4WAY_HANDSHAKE_FAILED:
			NET_MSG_INF("NET_CTRL_MSG_NETWORK_DOWN\n");
			break;
		case NET_CTRL_MSG_WLAN_CONNECT_FAILED:
			NET_MSG_INF("NET_CTRL_MSG_WLAN_CONNECT_FAILED\n");
			break;
		case NET_CTRL_MSG_CONNECTION_LOSS:
			NET_MSG_INF("NET_CTRL_MSG_CONNECTION_LOSS\n");
			break;
		case NET_CTRL_MSG_NETWORK_UP:
			NET_MSG_INF("NET_CTRL_MSG_NETWORK_UP\n");
			break;
		case NET_CTRL_MSG_NETWORK_DOWN:
			NET_MSG_INF("NET_CTRL_MSG_NETWORK_DOWN\n");
			break;
#if (!defined(__CONFIG_LWIP_V1) && LWIP_IPV6)
		case NET_CTRL_MSG_NETWORK_IPV6_STATE:
			break;
#endif		
		default:
			NET_MSG_INF("unknown msg (%u, %u)\n", type, data);
			break;
	}
}

int net_service_create(void)
{
	observer_base *ob;

	ob = sys_callback_observer_create(CTRL_MSG_TYPE_NETWORK,
									  NET_CTRL_MSG_ALL,
									  net_event_ob,
									  NULL);
	if (ob == NULL)
		return -1;
	if (sys_ctrl_attach(ob) != 0)
		return -1;
		
	return 0;
}

