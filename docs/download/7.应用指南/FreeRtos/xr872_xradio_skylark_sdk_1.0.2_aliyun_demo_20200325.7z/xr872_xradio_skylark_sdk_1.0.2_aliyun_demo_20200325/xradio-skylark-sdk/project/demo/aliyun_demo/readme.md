#  演示工程

> aliyun_demo用于演示基于阿里云物联网平台实现MQTT连接、订阅、发布等功能。

---

## 适用平台

> 本工程适用以下芯片类型：
>
> 1. XR872系列芯片

> 本工程适用SDK版本：XR872SDK V1.0.2
>
> 获取SDK链接：
> https://github.com/XradioTech/xradio-skylark-sdk.git

> XRadio Wireless MCU芯片和评估板的更多信息可在以下地址获取：
> https://docs.xradiotech.com

## 工程配置

> localconfig.mk：
> * __CONFIG_WLAN_STA: 使用STA模式时将此项置为y
> * __CONFIG_WLAN_STA_WPS： 使用STA模式并且使用WPS功能时，将此项置为y，注意不能与__CONFIG_WLAN_STA同时置为y
> * __CONFIG_WLAN_AP： 使用AP模式时将此项置为y
>
> Makefile：
> * IMAGE_CFG: 选择工程的flash布局文件。如无，则使用默认配置
> * LINKER_SCRIPT: 选择工程的ld文件。如无，则使用默认ld文件
> * PRJ_BOARD：必选项，选择板子的板级配置路径
>
> board_config.h
> * N/A
>
> board_config.c
> * N/A
>
> prj_config.h
>
> * PRJCONF_CONSOLE_EN: 必选项，配置使用控制台
> * PRJCONF_NET_EN: 必选项，配置使用网络

## 模块依赖

> libaliyun.a: aliyun云端对接库


---

## 工程说明

> 1.支持阿里云MQTT订阅、发布接口使用。
> 2.更新MQTT TLS支持补丁(include以及src文件), 支持MQTT_TLS_MODE、MQTT_TCP_MODE模式，可通过#define SECURE_MODE MQTT_TLS_MODE进行配置。

### 操作说明

> 1.更新阿里云补丁支持MQTT_TLS_MODE，将include以及src覆盖原目录文件。
> 2.修改默认连接热点“testap”以及热点密码，编译demo/aliyun_demo烧录到开发板中，重启运行程序可连接阿里云平台进行MQTT通讯。
> XRadio SDK的编译、烧写等操作方式的说明可在以下地址获取：
> https://github.com/XradioTech/xradiotech-wiki

### 控制命令

> N/A

### 代码结构
```
#本工程
.
├── gcc
│   ├── localconfig.mk          # 本工程的配置选项，主要用于覆盖默认全局配置
│   └── Makefile                # 本工程的编译规则，如ld文件、image.cfg、board_config.h等文件指定，可覆盖默认配置
├── image
│   └── xr872
│       └── image.cfg           # 本工程的镜像布局配置
├── main.c                      # 本工程的入口，完成平台初始化
├── command.c                   # 本工程的控制台命令入口
├── command.h
├── prj_config.h                # 本工程的配置选项，主要用于功能的选择。
└── readme.md                   # 本工程的说明文档

#本工程用到XRadio SDK的其他配置文件
.
└── project
    └── common
        └── board
            └── xradio_evb             #本工程在Makefile中指定使用xradio_evb的板级配置
                ├── board_config.h     #本工程的板级配置，
                └── board_config.c     #本工程的板级pin mux的配置。
```
### 代码流程

> 1. N/A


---


## 常见问题

> N/A
