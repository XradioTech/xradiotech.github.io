#  功能说明

> alios-things添加PSRAM的支持。

---

## 适用平台

> 本工程适用以下芯片类型：
> 1. XR872AT

> 本工程适用SDK版本：AOS-R-3.0.0
>
> 获取SDK链接：
> https://github.com/XradioTech/xradio-skylark-sdk

> XRadio Wireless MCU芯片和评估板的更多信息可在以下地址获取：
> https://docs.xradiotech.com

### 操作说明

> 将psram拷贝到platform/mcu/xr872/drivers/src/driver/chip/目录下
> 打上补丁0001-support-psram.patch
> 修改编译工程的相应cfg文件，在里面添加上app-psram.bin。


## 工程配置
> 参考附件的image-helloworld.cfg

---

## 常见问题

> N/A
