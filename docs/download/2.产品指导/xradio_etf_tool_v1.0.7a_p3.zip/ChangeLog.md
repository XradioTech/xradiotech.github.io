﻿ETF image：
version：1.0.0-rel-20191211

- 修改读取温度和电压的转换公式

ETF image：
version：1.0.0-rel-20191209

- 调整电压

ETF GUI tool
version：v1.0.7a

- RX误包率使用实际收包与预期收包差值的绝对值进行计算
- 使用列表框显示SDD power
- 调整界面，适应小分辨率的显示器
- 修复LOG过多后不更新的问题

ETF image：
version：1.0.0-rls-20191205

- 添加channel功率校准功能

ETF image：
version：1.0.0-rc2-20191114

- 修复RF性能mask相关问题

ETF image：
version：1.0.0-rc2-20191108

- 开放ETF模式下发射功率的限制

ETF GUI tool
version：v1.0.6d

- RX误包率显示只读

version：v1.0.6c

- 修改etf命令的结果判定
- RX误包率显示只到小数点后2位

version：v1.0.6b

- 修复win10串口接收不换行、串口接收数据慢的兼容性问题
- 添加Total Pkt，修改Rx误报率的计算方式
- 修改保存SDD数据方式为可选择保存位置

version：v1.0.6a

- 添加切换LDO、DCDC power mode
- 添加Rx误报率显示

version：v1.0.5b

- 修复串口接收数据慢、卡顿的问题
- 修改为Tx、Rx时不给选信道和速率

ETF GUI tool
version：v1.0.5a

* 修改XR871和XR809版本兼容的一些问题

ETF GUI tool
version：v1.0.4b

* 修改默认使用自动长度

ETF GUI tool
version：v1.0.4a

* 增加帮助信息和参数设置范围

ETF image：
version：1.0.0_beta_tst_10905p(add ota)
* 启动默认使用SDD的频偏值；
* 修复一些内存问题；
* 更新9.04的fw版本；
* 添加dcdc相关命令；

version：1.0.0_beta_10815a
* 增加适用于xradio sdk v1.0.0 beta 版本的ETF 测试镜像文件
* 包含24M和40M晶振两个版本
* 驱动增加设置和获取频偏的功能
* 目前仅支持控制台输入命令进行测试，详细使用请咨询相关FAE