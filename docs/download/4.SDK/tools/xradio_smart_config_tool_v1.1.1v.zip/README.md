# XRadio Smart Config Tool

> XRadio Smart Config Tool是深圳芯之联科技有限公司 (Xradio Technology) 用于其SDK上以自己的算法实现配网功能的工具
>
> 支持芯片：XR808系列芯片、XR872系列芯片。
> 使用说明：使用android设备安装改工具，然后进行配网操作即可，详细使用请咨询相关FAE
> 版本说明：请查看[ChangeLog.md](./ChangeLog.md)
