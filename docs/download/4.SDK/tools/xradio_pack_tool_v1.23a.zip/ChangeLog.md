﻿version：1.23a

- 增加合并固件的母片烧录所需要的裸固件生成功能

version：1.21c

- 增加合并固件功能，带有合并固件的头部信息

version：1.20r

- 增加写raw bin文件的功能，raw bin不带头部信息

version：1.11a

- 增加bin num字段处理，用于区分实际image的bin文件与user bin文件对image size的影响

version：1.10f

- flash加密功能直接使用key0进行加密，不再计算出key2后用key2进行加密

version：1.10e

- 当image max size没有被设置的话，就会报错
- 当image max size比实际的文件要小时，就会报错
- 增加了flash加密的功能，如果没有使用-e命令参数的话就不会被使能

version：1.9f

- 修复 获取cfg文件中的 image max_size、image xz_max_size 获取错误的问题

version：1.9e

- 增加获取cfg文件中的 image max_size、image xz_max_size 并存储在生成image文件中boot.bin private data区域中的功能

version：1.9d

* 修复一个内存越界的问题
* 修复打包文件只有一个时，增加自定义校验算法出错的问题