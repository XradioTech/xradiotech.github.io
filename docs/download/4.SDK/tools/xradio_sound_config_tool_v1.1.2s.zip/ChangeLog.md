Sound Config Tool version:1.1.2s

- 修改默认不保存pcm数据，可通过menu菜单打开或关闭保存pcm数据功能

Sound Config Tool version:1.1.2

- 修复保存pcm数据错误问题

Sound Config Tool version:1.1.1

- 修复policy2下实际发送数据显示错误的问题

Sound Config Tool version:1.1.0

* 增加版本号提示
* 增加循环压力测试功能选项