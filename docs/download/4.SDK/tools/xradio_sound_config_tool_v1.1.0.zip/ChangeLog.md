Sound Config Tool version:1.1.0

* 增加版本号提示
* 增加循环压力测试功能选项