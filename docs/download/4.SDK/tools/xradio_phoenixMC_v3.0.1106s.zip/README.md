# XRadio PhoenxMC Tool

> XRadio PhoenixMC Tool是深圳芯之联科技有限公司 (Xradio Technology) 用于其芯片固件烧写和调试使用的工具
>
> 支持芯片：XR808系列芯片、XR872系列芯片。
> 使用说明：支持windows、linux和IOS平台，windows平台有GUI和CLI两种选择，并且提供dll库文件供用户自行开发软件应用，详细使用请咨询相关FAE
> 版本说明：请查看[ChangeLog.md](./ChangeLog.md)

