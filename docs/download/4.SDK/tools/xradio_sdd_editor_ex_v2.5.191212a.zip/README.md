﻿# XRadio Sdd Editor

> XRadio Sdd Editor是深圳芯之联科技有限公司 (Xradio Technology) 用于其SDK上编辑配置文件（wlan_sdd.bin）所使用的工具
>
> 支持芯片：XR808系列芯片、XR872系列芯片。
> 使用说明：在windows平台下打开使用，详细使用规则请咨询相关FAE
> 版本说明：请查看[ChangeLog.md](./ChangeLog.md)
