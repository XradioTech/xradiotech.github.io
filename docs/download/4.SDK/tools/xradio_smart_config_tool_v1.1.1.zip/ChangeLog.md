Smart Config Tool version:1.1.1

- apk名称由XConfig.apk更改为SmartConfig.apk
- 优化非压力测试下设备连接指定Wi-Fi成功，但是没有自动结束发送流程的问题

Smart Config Tool version:1.1.0

* 增加版本号提示
* 增加循环压力测试功能选项

