
#ifndef _PHOENIXMC_LIB_H_
#define _PHOENIXMC_LIB_H_

#pragma once

#define LINKAGE	__declspec(dllexport)

#ifdef __cplusplus
extern "C"
{
#endif

	/************************************************************
	*                         flash use                         *
	************************************************************/
	//Function:	Init UART and synchron
	//Param:	com: UART COM port
	//			baud: UART baudrate, support rate:9600/115200/921600/1000000/1500000/3000000
	//Return:	not -1 - handle value		-1 - Failed
	LINKAGE int PMC_InitHandle(DWORD com, DWORD baud);

	//Function:	Deinit UART
	//Param:	handle: handle value of device
	//Return:	no
	LINKAGE void PMC_DeinitByHandle(int handle);

	//Function:	Get the version of PMC lib
	//Param:	no
	//Return:	pointer of version string
	LINKAGE char* PMC_GetVersion(void);

	//Function:	Get last status message of the module
	//Param:	no
	//Return:	pointer of message string
	LINKAGE char* PMC_GetMsg(void);

	//Function:	Get last status message	of the handle device
	//Param:	handle: handle value of device
	//Return:	pointer of message string
	LINKAGE char* PMC_GetMsgByHandle(int handle);

	//Function:	erase flash by 64K size
	//Param:	handle: handle value of device
	//			addr: address to be erase
	//			length: read/write data length, force aligned to 64K
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_EraseFlashByHandle(int handle, DWORD addr, DWORD length);

	//Function:	erase flash by 4K size
	//Param:	handle: handle value of device
	//			addr: address to be erase
	//			length: erase data length, force aligned to 4K
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_EraseFlashBy4KByHandle(int handle, DWORD addr, DWORD length);

	//Function:	Read flash
	//Param:	handle: handle value of device
	//			addr: address to be read
	//			data: data buffer
	//			length: read data length
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_ReadFlashByHandle(int handle, DWORD addr, BYTE *data, DWORD length);

	//Function:	Write flash
	//Param:	handle: handle value of device
	//			addr: address to be write
	//			data: data buffer
	//			length: write data length
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_WriteFlashByHandle(int handle, DWORD addr, BYTE *data, DWORD length);

	/************************************************************
	*                         FwParser use                      *
	************************************************************/
	struct ImageBinHeader
	{
		DWORD magic;
		DWORD version;
		WORD hchsum;
		WORD dchsum;
		DWORD dsize;
		DWORD load_addr;
		DWORD entry_point;
		DWORD img_len;
		DWORD img_attr;
		DWORD next_section_addr;
		BYTE name[4];
		BYTE priv[24];
	};

	//Function:	Init FwParser
	//Param:	no
	//Return:	not -1 - handle value		-1 - Failed
	LINKAGE int PMC_FwParserInitHandle(void);

	//Function:	Deinit FwParser
	//Param:	handle: handle value of device
	//Return:	no
	LINKAGE void PMC_FwParserDeinitByHandle(int handle);

	//Function:	Set image file path
	//Param:	handle: handle value of device
	//			filePath: pointer of image file path
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_FwParserSetFilePathByHandle(int handle, char* filePath);

	//Function:	Get image file path
	//Param:	handle: handle value of device
	//Return:	pointer of image file path		NULL - Failed
	LINKAGE char* PMC_FwParserGetFilePathByHandle(int handle);

	//Function:	Parse the image file set before
	//Param:	handle: handle value of device
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_FwParserFileParseByHandle(int handle);

	//Function:	Get the number of bins in image file, must be called after PMC_FwParserFileParse()
	//Param:	handle: handle value of device
	//Return:	number of bins - Success		-1 - Failed
	LINKAGE int PMC_FwParserGetBinCntByHandle(int handle);

	//Function:	Get the bin headers structure group, must be called after PMC_FwParserFileParse()
	//Param:	handle: handle value of device
	//Return:	group of bin headers - Success		NULL - Failed
	LINKAGE ImageBinHeader** PMC_FwParserGetFileInfoByHandle(int handle);

	//Function:	Get the OTA address of image file, must be called after PMC_FwParserFileParse()
	//Param:	handle: handle value of device
	//Return:	OTA address - Success		0xFFFFFFFF - Failed
	LINKAGE DWORD PMC_FwParserGetOtaAddrByHandle(int handle);

	//Function:	Get the OTA size of image file, must be called after PMC_FwParserFileParse()
	//Param:	handle: handle value of device
	//Return:	OTA size - Success		0xFFFFFFFF - Failed
	LINKAGE DWORD PMC_FwParserGetOtaSizeByHandle(int handle);

	/************************************************************
	*                           OTA use                         *
	************************************************************/
	//Function:	Gerate the OTA data by ota_size
	//Param:	data: data buffer to receive OTA data, must bigger than 4K
	//			len: length of OTA data buffer
	//			ota_size: size of OTA area mark in image file
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_GerateOTABuf(BYTE *data, DWORD len, DWORD ota_size);



	/************************************************************
	*                   old API(DO NOT USE)                     *
	************************************************************/
	//Function:	Init UART and synchron
	//Param:	com: UART COM port
	//			baud: UART baudrate, support rate:9600/115200/921600/1000000/1500000/3000000
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_Init(DWORD com, DWORD baud);
	LINKAGE void PMC_Deinit(void);

	//Function:	erase flash by 64K size
	//Param:	addr: address to be erase
	//			length: read/write data length, force aligned to 64K
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_EraseFlash(DWORD addr, DWORD length);

	//Function:	erase flash by 4K size
	//Param:	addr: address to be erase
	//			length: erase data length, force aligned to 4K
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_EraseFlashBy4K(DWORD addr, DWORD length);

	//Function:	Read flash
	//Param:	addr: address to be read
	//			data: data buffer
	//			length: read data length
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_ReadFlash(DWORD addr, BYTE *data, DWORD length);

	//Function:	Write flash
	//Param:	addr: address to be write
	//			data: data buffer
	//			length: write data length
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_WriteFlash(DWORD addr, BYTE *data, DWORD length);

	/************************************************************
	*                         FwParser use                      *
	************************************************************/
	//Function:	Init FwParser
	//Param:	no
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_FwParserInit(void);
	LINKAGE void PMC_FwParserDeinit(void);

	//Function:	Set image file path
	//Param:	filePath: pointer of image file path
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_FwParserSetFilePath(char* filePath);

	//Function:	Get image file path
	//Param:	no
	//Return:	pointer of image file path		NULL - Failed
	LINKAGE char* PMC_FwParserGetFilePath(void);

	//Function:	Parse the image file set before
	//Param:	no
	//Return:	0 - Success		-1 - Failed
	LINKAGE int PMC_FwParserFileParse(void);

	//Function:	Get the number of bins in image file, must be called after PMC_FwParserFileParse()
	//Param:	no
	//Return:	number of bins - Success		-1 - Failed
	LINKAGE int PMC_FwParserGetBinCnt(void);

	//Function:	Get the bin headers structure group, must be called after PMC_FwParserFileParse()
	//Param:	no
	//Return:	group of bin headers - Success		NULL - Failed
	LINKAGE ImageBinHeader** PMC_FwParserGetFileInfo(void);

	//Function:	Get the OTA address of image file, must be called after PMC_FwParserFileParse()
	//Param:	no
	//Return:	OTA address - Success		0xFFFFFFFF - Failed
	LINKAGE DWORD PMC_FwParserGetOtaAddr(void);

	//Function:	Get the OTA size of image file, must be called after PMC_FwParserFileParse()
	//Param:	no
	//Return:	OTA size - Success		0xFFFFFFFF - Failed
	LINKAGE DWORD PMC_FwParserGetOtaSize(void);

#ifdef __cplusplus
}
#endif

#endif // #ifndef _PHOENIXMC_LIB_H_